/*
 * libc/exit/exit.c
 */

#include <exit.h>

void exit(int status)
{
	while(1);
}
