/*
 * libc/exit/assert.c
 */

#include <assert.h>

void __assert_fail(const char * file, int line, const char * func, const char * expr)
{
}
