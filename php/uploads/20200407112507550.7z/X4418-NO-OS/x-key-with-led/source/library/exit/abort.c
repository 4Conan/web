/*
 * libc/exit/abort.c
 */

#include <exit.h>

void abort(void)
{
	 while(1);
}
