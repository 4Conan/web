/*
 * hw-key.c
 *
 * Copyright(c) 2007-2014 Jianjun Jiang <8192542@qq.com>
 * Official site: http://xboot.org
 * Mobile phone: +86-18665388956
 * QQ: 8192542
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <types.h>
#include <io.h>
#include <stddef.h>
#include <s5p4418-gpio.h>
#include <hw-key.h>

/*
 * MENU  -> S5P4418_GPIOB(9)
 * UP    -> S5P4418_GPIOB(31)
 * DOWN  -> S5P4418_GPIOB(30)
 * ENTER -> S5P4418_GPIOA(28)
 */
void key_initial(void)
{
	/* MENU */
	gpio_set_pull(S5P4418_GPIOB(9), GPIO_PULL_UP);
	gpio_direction_input(S5P4418_GPIOB(9));

	/* UP */
	gpio_set_pull(S5P4418_GPIOB(31), GPIO_PULL_UP);
	gpio_direction_input(S5P4418_GPIOB(31));

	/* DOWN */
	gpio_set_pull(S5P4418_GPIOB(30), GPIO_PULL_UP);
	gpio_direction_input(S5P4418_GPIOB(30));

	/* ENTER */
	gpio_set_pull(S5P4418_GPIOA(28), GPIO_PULL_UP);
	gpio_direction_input(S5P4418_GPIOA(28));
}

static u32_t __get_key_status(void)
{
	u32_t key = 0;

	if(gpio_get_value(S5P4418_GPIOB(9)) == 0)
		key |= KEY_NAME_MENU;

	if(gpio_get_value(S5P4418_GPIOB(31)) == 0)
		key |= KEY_NAME_UP;

	if(gpio_get_value(S5P4418_GPIOB(30)) == 0)
		key |= KEY_NAME_DOWN;

	if(gpio_get_value(S5P4418_GPIOA(28)) == 0)
		key |= KEY_NAME_ENTER;

	return key;
}

bool_t get_key_status(u32_t * key)
{
	static u32_t a = 0, b = 0, c = 0;

	a = __get_key_status();
	b = __get_key_status();
	c = __get_key_status();

	if((a == b) && (a == c))
	{
		*key = a;
		return TRUE;
	}

	return FALSE;
}

bool_t get_key_event(u32_t * keyup, u32_t * keydown)
{
	static u32_t key_old = 0x0;
	u32_t key;

	if(!get_key_status(&key))
		return FALSE;

	if(key != key_old)
	{
		*keyup = (key ^ key_old) & key_old;
		*keydown = (key ^ key_old) & key;
		key_old = key;

		return TRUE;
	}

	return FALSE;
}

