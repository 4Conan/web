/*
 * hw-led.c
 *
 * Copyright(c) 2007-2014 Jianjun Jiang <8192542@qq.com>
 * Official site: http://xboot.org
 * Mobile phone: +86-18665388956
 * QQ: 8192542
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <types.h>
#include <io.h>
#include <s5p4418-gpio.h>
#include <hw-led.h>

/*
 * LED1 -> S5P4418_GPIOB(28)
 * LED2 -> S5P4418_GPIOC(11)
 * LED3 -> S5P4418_GPIOC(7)
 * LED4 -> S5P4418_GPIOC(12)
 */
void led_initial(void)
{
	/* LED1 */
	gpio_set_pull(S5P4418_GPIOB(28), GPIO_PULL_UP);
	gpio_direction_output(S5P4418_GPIOB(28), 1);

	/* LED2 */
	gpio_set_pull(S5P4418_GPIOC(11), GPIO_PULL_UP);
	gpio_direction_output(S5P4418_GPIOC(11), 1);

	/* LED3 */
	gpio_set_pull(S5P4418_GPIOC(7), GPIO_PULL_UP);
	gpio_direction_output(S5P4418_GPIOC(7), 1);

	/* LED4 */
	gpio_set_pull(S5P4418_GPIOC(12), GPIO_PULL_UP);
	gpio_direction_output(S5P4418_GPIOC(12), 1);
}

void led_set_status(enum led_name name, enum led_status status)
{
	switch(name)
	{
	case LED_NAME_LED1:
		if(status == LED_STATUS_ON)
			gpio_direction_output(S5P4418_GPIOB(28), 0);
		else if(status == LED_STATUS_OFF)
			gpio_direction_output(S5P4418_GPIOB(28), 1);
		break;

	case LED_NAME_LED2:
		if(status == LED_STATUS_ON)
			gpio_direction_output(S5P4418_GPIOC(11), 0);
		else if(status == LED_STATUS_OFF)
			gpio_direction_output(S5P4418_GPIOC(11), 1);
		break;

	case LED_NAME_LED3:
		if(status == LED_STATUS_ON)
			gpio_direction_output(S5P4418_GPIOC(7), 0);
		else if(status == LED_STATUS_OFF)
			gpio_direction_output(S5P4418_GPIOC(7), 1);
		break;

	case LED_NAME_LED4:
		if(status == LED_STATUS_ON)
			gpio_direction_output(S5P4418_GPIOC(12), 0);
		else if(status == LED_STATUS_OFF)
			gpio_direction_output(S5P4418_GPIOC(12), 1);
		break;

	default:
		break;
	}
}
