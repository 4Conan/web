#include <main.h>

extern int tester_key_with_led(int argc, char * argv[]);

static void do_system_initial(void)
{
	malloc_init();

	s5p4418_clk_init();
	s5p4418_irq_init();
	s5p4418_gpiochip_init();
	s5p4418_pwm_init();
	s5p4418_serial_initial();
	s5p4418_tick_initial();
	s5p4418_tick_delay_initial();
	s5p4418_fb_initial();

	led_initial();
	beep_initial();
	key_initial();
}

int main(int argc, char * argv[])
{
	do_system_initial();

	tester_key_with_led(argc, argv);
	return 0;
}
