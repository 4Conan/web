#ifndef __S5P4418_CLK_H__
#define __S5P4418_CLK_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <s5p4418-rstcon.h>
#include <s5p4418/reg-sys.h>
#include <s5p4418/reg-clk.h>
#include <s5p4418/reg-timer.h>
#include <s5p4418/reg-pwm.h>
#include <clk/clk.h>

void s5p4418_clk_init(void);
void s5p4418_clk_exit(void);

#ifdef __cplusplus
}
#endif

#endif /* __S5P4418_CLK_H__ */
