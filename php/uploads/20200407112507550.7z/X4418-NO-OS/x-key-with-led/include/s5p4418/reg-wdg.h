#ifndef __S5P4418_REG_WDG_H__
#define __S5P4418_REG_WDG_H__

#define S5P4418_WTCON	  		(0xC0019000 + 0x00)
#define S5P4418_WTDAT	  		(0xC0019000 + 0x04)
#define S5P4418_WTCNT	  		(0xC0019000 + 0x08)
#define S5P4418_WTCLRINT  		(0xC0019000 + 0x0c)

#endif /* __S5P4418_REG_WDG_H__ */
