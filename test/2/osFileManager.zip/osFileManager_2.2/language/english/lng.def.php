<?php
$LNG_NAME = "English";
?>