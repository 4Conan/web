<?php
$LNG_NAME = "Chinese";
?>