<?die;?>
administrators|newfile|newdir|downfile|upfile|savefromurl|delete|zippack|unpack|select|copy|move|viewsorce|rename|savefile|property|admin|adduser|deluser|delgroup|addgroup|search|
�ο�|visit|big|downfile|select|property|&php&asp&jsp&aspx&php3&cgi&cer&cdx&asa|
