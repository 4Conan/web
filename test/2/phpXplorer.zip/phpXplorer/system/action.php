<?php

require(dirname(__FILE__) . "/includes.php");

$pxp = new pxCLS_system();

$pxp->runAction();

?>