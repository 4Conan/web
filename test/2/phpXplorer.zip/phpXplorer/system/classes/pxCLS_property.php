<?php

class pxCLS_property{

	var $id;

	function pxCLS_property(){
		
	}
}


?>