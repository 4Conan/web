<?php

array_push($this->aTranslators["de"], array("Tobias Bender", "tobias@pxpxplorer.org", "http://www.phpxplorer.org"));

$this->aLanguages["de"] = array_merge($this->aLanguages["de"], array(
  'action.edit_text_html_tinymce' => 'TinyMCE'
));

?>