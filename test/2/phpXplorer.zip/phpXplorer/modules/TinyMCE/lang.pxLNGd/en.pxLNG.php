<?php

array_push($this->aTranslators["en"], array("Tobias Bender", "tobias@pxpxplorer.org", "http://www.phpxplorer.org"));

$this->aLanguages["en"] = array_merge($this->aLanguages["en"], array(
  'action.edit_text_html_tinymce' => 'TinyMCE'
));

?>