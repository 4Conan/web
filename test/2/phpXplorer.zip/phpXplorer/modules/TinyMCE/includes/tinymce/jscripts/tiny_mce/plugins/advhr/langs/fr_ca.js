// CA_FR lang variables

tinyMCELang['lang_insert_advhr_desc']    = 'Ins�rer / Modifier S�parateur Horizontal';
tinyMCELang['lang_insert_advhr_width']   = 'Largeur';
tinyMCELang['lang_insert_advhr_size']    = 'Hauteur';
tinyMCELang['lang_insert_advhr_noshade'] = 'Sans ombrage';
