// CAN_FR lang variables

tinyMCELang['lang_preview_desc'] = 'Pr�visualisation';
