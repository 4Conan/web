// DE lang variables 

tinyMCELang['lang_insertdate_desc'] = 'Datum einf&uuml;gen';
tinyMCELang['lang_inserttime_desc'] = 'Zeit einf&uuml;gen';
tinyMCELang['lang_inserttime_months_long'] = new Array("Januar", "Februar", "M\u00e4rz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember");
tinyMCELang['lang_inserttime_months_short'] = new Array("Jan", "Feb", "M\u00e4r", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez");
tinyMCELang['lang_inserttime_day_long'] = new Array("Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag");
tinyMCELang['lang_inserttime_day_short'] = new Array("So", "Mo", "Di", "Mi", "Do", "Fr", "Sa", "So");
