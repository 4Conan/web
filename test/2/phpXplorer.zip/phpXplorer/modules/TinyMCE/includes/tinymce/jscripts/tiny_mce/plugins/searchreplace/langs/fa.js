﻿// IR lang variables
// Persian (Farsi) language pack (for IRAN)
// By: Morteza Zafari
// Lost@LostLord.com
// http://www.LostLord.com

tinyMCELang['lang_dir'] = 'rtl';
tinyMCELang['lang_searchreplace_search_desc'] = 'جستجو';
tinyMCELang['lang_searchreplace_searchnext_desc'] = 'جستجوي مجدد';
tinyMCELang['lang_searchreplace_replace_desc'] = 'جستجو/جايگزيني';
tinyMCELang['lang_searchreplace_notfound'] = 'جستجو پايان يافت. هيچ موردي يافت نشد.';
tinyMCELang['lang_searchreplace_search_title'] = 'جستجو';
tinyMCELang['lang_searchreplace_replace_title'] = 'جستجو/جايگزيني';
tinyMCELang['lang_searchreplace_allreplaced'] = 'همه موارد جايگزين گرديد.';
tinyMCELang['lang_searchreplace_findwhat'] = 'جستجو به دنبال';
tinyMCELang['lang_searchreplace_replacewith'] = 'جايگزيني با';
tinyMCELang['lang_searchreplace_direction'] = 'جهت جستجو';
tinyMCELang['lang_searchreplace_up'] = 'به سمت بالا';
tinyMCELang['lang_searchreplace_down'] = 'به سمت پايين';
tinyMCELang['lang_searchreplace_case'] = 'تطبيق حروف کوچک و بزرگ';
tinyMCELang['lang_searchreplace_findnext'] = 'مورد-بعدي';
tinyMCELang['lang_searchreplace_replace'] = 'جايگزين-کن';
tinyMCELang['lang_searchreplace_replaceall'] = 'جايگزيني-همه';
tinyMCELang['lang_searchreplace_cancel'] = 'بيخيال';
