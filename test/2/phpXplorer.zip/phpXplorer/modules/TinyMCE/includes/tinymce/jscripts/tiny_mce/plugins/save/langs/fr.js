// French lang variables by Laurent Dran

tinyMCELang['lang_save_desc'] = 'Sauver'; 
