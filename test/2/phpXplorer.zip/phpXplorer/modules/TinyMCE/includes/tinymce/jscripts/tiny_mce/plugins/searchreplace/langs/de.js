// DE lang variables 

tinyMCELang['lang_searchreplace_search_desc'] = 'Suchen';
tinyMCELang['lang_searchreplace_searchnext_desc'] = 'Erneut suchen';
tinyMCELang['lang_searchreplace_replace_desc'] = 'Suchen/Ersetzen';
tinyMCELang['lang_searchreplace_notfound'] = 'Die Suche wurde abgeschlossen. Das Suchwort wurde nicht gefunden.';
tinyMCELang['lang_searchreplace_search_title'] = 'Suchen';
tinyMCELang['lang_searchreplace_replace_title'] = 'Suchen/Ersetzen';
tinyMCELang['lang_searchreplace_allreplaced'] = 'Die Suche wurde abgeschlossen. Alle Vorkommen wurden ersetzt.';
tinyMCELang['lang_searchreplace_findwhat'] = 'Suchen nach';
tinyMCELang['lang_searchreplace_replacewith'] = 'Ersetzem durch';
tinyMCELang['lang_searchreplace_direction'] = 'Suchrichtung';
tinyMCELang['lang_searchreplace_up'] = 'R&uuml;ckw&auml;rts';
tinyMCELang['lang_searchreplace_down'] = 'Vorw&auml;rts';
tinyMCELang['lang_searchreplace_case'] = 'Gro&szlig;-/Kleinschreibung beachten';
tinyMCELang['lang_searchreplace_findnext'] = 'Weiter suchen';
tinyMCELang['lang_searchreplace_replace'] = 'Ersetzen';
tinyMCELang['lang_searchreplace_replaceall'] = 'Alle ersetzen';
tinyMCELang['lang_searchreplace_cancel'] = 'Abbrechen';
