﻿// IR lang variables
// Persian (Farsi) language pack (for IRAN)
// By: Morteza Zafari
// Lost@LostLord.com
// http://www.LostLord.com

tinyMCELang['lang_dir'] = 'rtl';
tinyMCELang['lang_insert_image_alt2'] = 'عنوان عکس';
tinyMCELang['lang_insert_image_onmousemove'] = 'عکس جایگزین'
tinyMCELang['lang_insert_image_mouseover'] = 'عکس جایگزین هنگام ورود نشانگر ماوس';
tinyMCELang['lang_insert_image_mouseout'] = 'عکس جایگزین هنگام خروج نشانگر ماوس';
