// Simplified Chinese lang variables contributed by cube316 (cube316@etang.com)

tinyMCELang['lang_insertdate_desc'] = '���뵱ǰ����';
tinyMCELang['lang_inserttime_desc'] = '���뵱ǰʱ��';
tinyMCELang['lang_inserttime_months_long'] = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
tinyMCELang['lang_inserttime_months_short'] = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
tinyMCELang['lang_inserttime_day_long'] = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
tinyMCELang['lang_inserttime_day_short'] = new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun");
