// CA_FR lang variables

tinyMCELang['lang_insert_flash']      = 'Ins�rer / Modifier une animation Flash';
tinyMCELang['lang_insert_flash_file'] = 'Fichier Flash (.swf)';
tinyMCELang['lang_insert_flash_size'] = 'Dimension';
tinyMCELang['lang_flash_props'] = 'Flash properties';
