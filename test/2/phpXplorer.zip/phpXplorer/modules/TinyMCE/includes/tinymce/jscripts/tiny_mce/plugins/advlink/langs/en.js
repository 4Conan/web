// UK lang variables

tinyMCELang['lang_insert_link_target_same'] = 'Open in this window / frame';
tinyMCELang['lang_insert_link_target_parent'] = 'Open in parent window / frame';
tinyMCELang['lang_insert_link_target_top'] = 'Open in top frame (replaces all frames)';
tinyMCELang['lang_insert_link_target_blank'] = 'Open in new window';
tinyMCELang['lang_insert_link_target_named'] = 'Open in the window';
tinyMCELang['lang_insert_link_popup'] = 'JS-Popup';
tinyMCELang['lang_insert_link_popup_url'] = 'Popup URL';
tinyMCELang['lang_insert_link_popup_name'] = 'Window name';
tinyMCELang['lang_insert_link_popup_return'] = 'insert \'return false\'';
tinyMCELang['lang_insert_link_popup_scrollbars'] = 'Show scrollbars';
tinyMCELang['lang_insert_link_popup_statusbar'] = 'Show statusbar';
tinyMCELang['lang_insert_link_popup_toolbar'] = 'Show toolbars';
tinyMCELang['lang_insert_link_popup_menubar'] = 'Show menubar';
tinyMCELang['lang_insert_link_popup_location'] = 'Show locationbar';
tinyMCELang['lang_insert_link_popup_resizable'] = 'Make window resizable';
tinyMCELang['lang_insert_link_popup_size'] = 'Size';
tinyMCELang['lang_insert_link_popup_position'] = 'Position (X/Y)';
tinyMCELang['lang_insert_link_popup_missingtarget'] = 'Please insert a name for the target or choose another option.';
